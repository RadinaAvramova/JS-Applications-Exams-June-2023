export class HomePage {
    constructor(templateFunction, render){
        this.templateFunction = templateFunction;
        this.render = render;
        this.showView = this._showView.bind(this);
    };

    async _showView(ctx, next) {
        let template = this.templateFunction();
        this.render(template);
        next();
    };
};