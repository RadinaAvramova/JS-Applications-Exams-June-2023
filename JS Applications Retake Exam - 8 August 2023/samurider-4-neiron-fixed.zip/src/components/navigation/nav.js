import page from "../../../node_modules/page/page.mjs";
export class NavBar{
    constructor(authService, templateFunction, render) {
        this.templateFunction = templateFunction;
        this.render = render;
        this.authService = authService;
        this.showView = this._showView.bind(this);
        this.logoutHandler = this._logoutHandler.bind(this);
    };

    async _showView(ctx, next) {
        //let isLogged = this.authService.isUserLoggedIn();
        let isLogged = await this.authService.isUserLoggedIn();
        let template = this.templateFunction(isLogged, this.logoutHandler);
        this.render(template);
        next();
    };

    async _logoutHandler() {
        await this.authService.logout();
        page.show('/')
    }
}