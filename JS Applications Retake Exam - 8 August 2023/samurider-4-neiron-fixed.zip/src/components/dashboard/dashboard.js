export class DashBoard {
    constructor(crudService, templateFunction, render) {
        this.crudService = crudService;
        this.templateFunction = templateFunction;
        this.render = render;
        this.showView = this._showView.bind(this);
    }

    async _showView(ctx, next) {
        let motorcycles = await this.crudService.getAll();
        let template = this.templateFunction(motorcycles);
        this.render(template);
        next();
    }
}