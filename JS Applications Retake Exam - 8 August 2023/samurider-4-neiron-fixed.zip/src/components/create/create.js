import page from "../../../node_modules/page/page.mjs";
export class CreatePage {
    constructor(crudService, templateFunction, render) {
        this.crudService = crudService;
        this.templateFunction = templateFunction;
        this.render = render;
        this.showView = this._showView.bind(this);
        this.createHandler = this._createHandler.bind(this);
    }

    async _showView(ctx, next) {
        let template = this.templateFunction(this.createHandler);
        this.render(template);
        next();
    }

    async _createHandler(e) {
        e.preventDefault();
        let form = e.target;
        let formData = new FormData(form);
        let year = formData.get('year');
        let model = formData.get('model');
        let imageUrl = formData.get('imageUrl');
        let mileage = formData.get('mileage');
        let contact = formData.get('contact');
        let about = formData.get('about');

        let info = { year, model, imageUrl, mileage, contact, about }

        if (year == '' || model == '' || imageUrl == '' || mileage == '' || contact == '' || about == '') {
            alert('Input fields must not be empty!');
            return;
        }
        try {
            let result = await this.crudService.create(info);
            page.show('/dashboard');
        } catch(err) {
            alert(err.message);
        };
    }
}