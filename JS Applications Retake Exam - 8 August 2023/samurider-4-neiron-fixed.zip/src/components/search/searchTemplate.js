import { html } from "../../../node_modules/lit-html/lit-html.js";

const motoTemplate = (motorcycle) => html`
<div class="motorcycle">
    <img src=${motorcycle.imageUrl} alt="example1" />
    <h3 class="model">${motorcycle.model}</h3>
      <a class="details-btn" href=${`/details/${motorcycle._id}`}>More Info</a>
</div>`

export const searchTemplate = (submitHandler, motorcycles) => html`
<section id="search">
<div class="form">
    <h4>Search</h4>
    <form class="search-form" @submit=${submitHandler}>
      <input
        type="text"
        name="search"
        id="search-input"
      />
      <button class="button-list">Search</button>
    </form>
</div>

<h4 id="result-heading">Results:</h4>
<div class="search-result">
    ${motorcycles.length > 0
        ? html`${motorcycles.map((motorcycle) => motoTemplate(motorcycle))}`
        : html`<h2 class="no-avaliable">No result.</h2>`
    }
</div>
</section>`