import page from "../../../node_modules/page/page.mjs";
export class EditPage {
    constructor(crudService, templateFunction, render) {
        this.crudService = crudService;
        this.templateFunction = templateFunction;
        this.render = render;
        this.showView = this._showView.bind(this);
        this.editHandler = this._editHandler.bind(this);
    }

    async _showView(ctx, next) {
        let id = ctx.params.id
        let motorcycle = await this.crudService.getById(id);
        let template = this.templateFunction(this.editHandler, motorcycle);
        this.render(template);
        next();
    }

    async _editHandler(e, id) {
        e.preventDefault();
        let form = e.target;
        let formData = new FormData(form);
        let year = formData.get('year');
        let model = formData.get('model');
        let imageUrl = formData.get('imageUrl');
        let mileage = formData.get('mileage');
        let contact = formData.get('contact');
        let about = formData.get('about');

        let info = { year, model, imageUrl, mileage, contact, about }

        if (year == '' || model == '' || imageUrl == '' || mileage == '' || contact == '' || about == '') {
            alert('Input fields must not be empty!');
            return;
        }
        
        let result = await this.crudService.edit(id, info);
        page.show(`/details/${id}`);
    }
}