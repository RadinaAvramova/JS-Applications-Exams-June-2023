import { html } from "../../../node_modules/lit-html/lit-html.js";

export const detailsTemplate = (motorcycle, isOwner, deleteHandler) => html`
<section id="details">
    <div id="details-wrapper">
      <img id="details-img" src=${motorcycle.imageUrl} alt="example1" />
      <p id="details-title">${motorcycle.model}</p>
      <div id="info-wrapper">
        <div id="details-description">
          <p class="year">Year: ${motorcycle.year}</p>
          <p class="mileage">Mileage: ${motorcycle.mileage} km.</p>
          <p class="contact">Contact Number: ${motorcycle.contact}</p>
             <p id = "motorcycle-description">${motorcycle.about}</p>
      </div>
      
       ${isOwner
    ? html`
    <div id="action-buttons">
        <a href=${`/edit/${motorcycle._id}`} id="edit-btn">Edit</a>
        <a href="javascript:void(0)" id="delete-btn" @click=${(e) => deleteHandler(motorcycle._id)}>Delete</a>
    </div>`

    : ''
  }
</section>`