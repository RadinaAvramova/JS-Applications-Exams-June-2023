import page from "../../../node_modules/page/page.mjs";

export class DetailsPage {
    constructor(crudService, templateFunction, render, authService) {
        this.crudService = crudService;
        this.authService = authService
        this.templateFunction = templateFunction;
        this.render = render;
        this.showView = this._showView.bind(this);
        this.deleteHandler = this._deleteHandler.bind(this);
    }

    async _showView(ctx, next) {
        let id = ctx.params.id;
        let motorcycle = await this.crudService.getById(id);
        let currentUserId = sessionStorage.getItem('userId');
        let isOwner = currentUserId === motorcycle._ownerId;
        let template = this.templateFunction(motorcycle, isOwner, this.deleteHandler);
        this.render(template);
        next();
    };

    async _deleteHandler(id) {
        let result = confirm('Are you sure you want to delete this item');
        if (result == false) {
            return;
        };

        let deleteResult = await this.crudService.del(id);
        page.show('/dashboard');
    }
}