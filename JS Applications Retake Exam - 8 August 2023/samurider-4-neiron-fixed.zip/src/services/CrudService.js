import { ApiService } from "./ApiService.js";

export class CrudService extends ApiService{
    constructor(baseUrl, path) {
        super(baseUrl);
        this.resourceUrl = `${this.baseUrl}${path}`;
    };

    async getAll() {
        const options = {
            method: 'GET',
        };
        let url = `${this.baseUrl}/data/motorcycles?sortBy=_createdOn%20desc`;
        const result = await this._internalFetcher(url, options);
        return result;
    };

    async getById(id) {
        const options = {
            method: 'GET',
        };
        let url = `${this.resourceUrl}/${id}`;
        const result = await this._internalFetcher(url, options);
        return result;
    };

    async create(item) {
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Authorization': sessionStorage.getItem('accessToken'),
            },
            body: JSON.stringify(item),
        }
        const result = await this._internalFetcher(this.resourceUrl, options);
        return result;
    };

    async edit(id, item) {
        const options = {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'X-Authorization': sessionStorage.getItem('accessToken'),
            },
            body: JSON.stringify(item),
        };
        let url = `${this.resourceUrl}/${id}`;
        const result = await this._internalFetcher(url, options);
        return result;
    };

    async del(id) {
        const options = {
            method: 'DELETE',
            headers: {
                'X-Authorization': sessionStorage.getItem('accessToken'),
            },
        };
        let url = `${this.resourceUrl}/${id}`;
        const result = await this._internalFetcher(url, options);
        return result;
    };

    async searchMotorcycles(value) {
        const options = {
            method: 'GET',
        };
        let url = `${this.resourceUrl}?where=model%20LIKE%20%22${value}%22`;
        const result = await this._internalFetcher(url, options);
        return result;
    };
}