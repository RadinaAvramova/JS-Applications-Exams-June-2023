import page from "../node_modules/page/page.mjs";
import { render } from "../node_modules/lit-html/lit-html.js";
import { NavBar } from "./components/navigation/nav.js";
import { navTemplate } from "./components/navigation/navTemplate.js";
import { ApiService } from "./services/ApiService.js";
import { AuthService } from "./services/AuthService.js";
import { CrudService } from "./services/CrudService.js";
import { HomePage } from "./components/home/home.js";
import { homeTemplate } from "./components/home/homeTemplate.js";
import { loginPage } from "./components/login/login.js";
import { loginTemplate } from "./components/login/loginTemplate.js";
import { RegisterPage } from "./components/register/register.js";
import { registerTemplate } from "./components/register/registerTemplate.js";
import { DashBoard } from "./components/dashboard/dashboard.js";
import { dashTemplate } from "./components/dashboard/dashTemplate.js";
import { DetailsPage } from "./components/details/details.js";
import { detailsTemplate } from "./components/details/detailsTemplate.js";
import { CreatePage } from "./components/create/create.js";
import { createTemplate } from "./components/create/createTemplate.js";
import { EditPage } from "./components/edit/edit.js";
import { editTemplate } from "./components/edit/editTemplate.js";
import { SearchPage } from "./components/search/search.js";
import { searchTemplate } from "./components/search/searchTemplate.js";

let baseUrl = 'http://localhost:3030';

let main = document.querySelector('#wrapper main');
let header = document.querySelector('#wrapper header');

//Render handlers
let renderBody = (template) => render(template, main);
let renderNav = (template) => render(template, header);

//Services
let authService = new AuthService(baseUrl);
let apiService = new ApiService(baseUrl);
let crudService = new CrudService(baseUrl, '/data/motorcycles');

//Components
let navComponent = new NavBar(authService, navTemplate, renderNav);
let homeComponent = new HomePage(homeTemplate, renderBody);
let loginComponent = new loginPage(loginTemplate, renderBody, authService);
let registeredComponent = new RegisterPage(registerTemplate, renderBody, authService);
let dashComponent = new DashBoard(crudService, dashTemplate, renderBody);
let detailsComponent = new DetailsPage(crudService, detailsTemplate, renderBody, authService);
let createComponent = new CreatePage(crudService, createTemplate, renderBody);
let editComponent = new EditPage(crudService, editTemplate, renderBody);
let searchComponent = new SearchPage(crudService, searchTemplate, renderBody);

page('/index.html', "/");
page(navComponent.showView);

page('/', homeComponent.showView);
page('/login', loginComponent.showView);
page('/register', registeredComponent.showView);
page('/dashboard', dashComponent.showView);
page('/create', createComponent.showView);
page('/details/:id', detailsComponent.showView);
page('/edit/:id', editComponent.showView);
page('/search', searchComponent.showView);
page.start()