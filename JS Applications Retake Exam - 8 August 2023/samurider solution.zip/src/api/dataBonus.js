import { get } from "./api.js";

export async function search(query) {
    return await get(`/data/motorcycles?where=model%20LIKE%20%22${query}%22`);
}



