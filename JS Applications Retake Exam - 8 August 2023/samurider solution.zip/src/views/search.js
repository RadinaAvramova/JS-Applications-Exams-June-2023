import { html } from '../lib.js';
import { search } from '../api/dataBonus.js';
import { getUserData } from '../util.js';

const searchTamplate = (moto, onSearch, user) => html`
<section id="search">

<div class="form">
  <h4>Search</h4>
  <form class="search-form">
    <input
      type="text"
      name="search"
      id="search-input"
    />
    <button class="button-list" @click=${onSearch}>Search</button>
  </form>
</div>
<h4 id="result-heading">Results:</h4>


            ${moto != undefined ? html `
  
                ${moto.length == 0 ? html`
                <h2 class="no-avaliable">No result.</h2>` : 
                moto.map(p => html`
    
                <div class="search-result">
 <div class="motorcycle">
  <img src="${p.imageUrl}" alt="example1" />
  <h3 class="model">${p.model}</h3>
    <a class="details-btn" href="/details/${p._id}">More Info</a>
</div>
`)}
            </div>
            `: ''}
        </section>
`;

export async function searchPage(ctx) {
  let user = getUserData(ctx.user);
  console.log(user);
  let moto = undefined;

const name = ctx.querystring.split('=')[1];
    if(name !== undefined) {
      moto = await search(name);
    }
    console.log(moto);
    ctx.render(searchTamplate(moto, onSearch, user));

    async function onSearch() {
        const query = document.querySelector('#search-input').value;
        if (query !== '') {
            ctx.page.redirect(`/search?query=${query}`);
        } else {
            return alert('All fields are required!');
        }
    }
}