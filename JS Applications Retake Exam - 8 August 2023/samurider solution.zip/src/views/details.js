import { deleteItem, getById } from '../api/data.js';
import { html, nothing } from '../lib.js';

const detailsTamplate = (
  details,
  isOwner,
  onDelete,
  isLoggedIn,
) => html`
<section id="details">
          <div id="details-wrapper">
            <img id="details-img" src="${details.imageUrl}" alt="example1" />
            <p id="details-title">${details.model}</p>
            <div id="info-wrapper">
              <div id="details-description">
                <p class="year">Year: ${details.year}</p>
                <p class="mileage">Mileage: ${details.mileage} km.</p>
                <p class="contact">Contact Number: ${details.contact}</p>
                   <p id = "motorcycle-description">
                   ${details.about}
                        </p>
              </div>
        <div id="action-buttons">
        ${(() => {
    if (isLoggedIn && isOwner) {
      return html`
            <a href="/edit/${details._id}" id="edit-btn">Edit</a>
            <a  id="delete-btn" @click=${onDelete}>Delete</a>
            `
    } else { nothing }
  })()}
          </div>
          </div>
          </div>
        </section>
`;

export async function detailsPage(ctx) {
  const eventId = ctx.params.id;
  const details = await getById(eventId);
  const user = ctx.user;

  let userId;

  if (user != null) {
    userId = user._id;
  }

  const isOwner = user && details._ownerId == user._id;
  const isLoggedIn = user !== undefined;

  ctx.render(detailsTamplate(
    details,
    isOwner,
    onDelete,
    isLoggedIn,

  )
  );

  async function onDelete() {
    const confirmed = confirm("Are you sure?");

    if (confirmed) {
      await deleteItem(eventId);
      ctx.page.redirect("/catalog");
    }
  }

}






