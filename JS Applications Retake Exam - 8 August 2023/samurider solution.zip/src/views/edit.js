import { edit, getById } from '../api/data.js';
import { html } from '../lib.js';

const editTemplate = (editText, onSubmit) => html`
<section id="edit">
            <h2>Edit Motorcycle</h2>
            <div class="form">
              <h2>Edit Motorcycle</h2>
              <form class="edit-form" @submit=${onSubmit}>
                <input
                  type="text"
                  name="model"
                  id="model"
                  placeholder="Model"
                  value="${editText.model}"
                />
                <input
                  type="text"
                  name="imageUrl"
                  id="moto-image"
                  placeholder="Moto Image"
                  value="${editText.imageUrl}"
                />
                <input
                type="number"
                name="year"
                id="year"
                placeholder="Year"
                value="${editText.year}"
              />
              <input
              type="number"
              name="mileage"
              id="mileage"
              placeholder="mileage"
              value="${editText.mileage}"
            />
            <input
              type="number"
              name="contact"
              id="contact"
              placeholder="contact"
              value="${editText.contact}"
            />
              <textarea
                id="about"
                name="about"
                placeholder="about"
                rows="10"
                cols="50"
              >${editText.about}</textarea>
                <button type="submit">Edit Motorcycle</button>
              </form>
          </div>
        </section>    
      `;

export async function showEdit(ctx) {
    const eventId = ctx.params.id;
    
    const editText = await getById(eventId);
    ctx.render(editTemplate(editText, onSubmit));
  
    async function onSubmit(event) {
      event.preventDefault();
      const formData = new FormData(event.target);
  
      const editT = {
        model: formData.get("model").trim(),
        imageUrl: formData.get("imageUrl").trim(),
        year: formData.get("year").trim(),
        mileage: formData.get("mileage").trim(),
        contact: formData.get("contact").trim(),
        about: formData.get("about").trim(),
      };
  
      if (Object.values(editT).some((x) => !x)) {
        return alert("All fields are required!");
      }
  
      await edit(eventId, editT);
      event.target.reset();
      ctx.page.redirect(`/details/${eventId}`);
    }
  }